pub fn add(left: usize, right: usize) -> usize {
    left + right
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn it_works() {
        let result = add(2, 2);
        assert_eq!(result, 4);
    }
}
use wasm_bindgen::prelude::*;
use serde::{Serialize, Deserialize};

#[wasm_bindgen]
extern {
    fn alert(s: &str);
}

#[derive(Serialize, Deserialize)]
struct Bid {
    CPM_Floor: f64,
    Amazon_Key_Value: String,
}

#[wasm_bindgen]
pub fn process_bids(json_bids: &str) -> String {
    let bids: Vec<Bid> = serde_json::from_str(json_bids).unwrap();
    // Process bids...
    let processed_bids = bids; // Example, replace with actual processing

    serde_json::to_string(&processed_bids).unwrap()
}
